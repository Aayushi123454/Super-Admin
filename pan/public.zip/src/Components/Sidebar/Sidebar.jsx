import { Link } from 'react-router-dom';
import React, { useState } from 'react';
import './Sidebar.css';
import { SidebarData } from './Sidebardata';
import { SidebarChild } from './Sidebardata';

export const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(true);
  const [activeParent, setActiveParent] = useState([]);
   const toggleSidebar = () => {
        setIsOpen(!isOpen);

   }
  const handleParentClick = (title) => {
    setActiveParent((prev) => (prev === title ? null : title));
  };

  const children = SidebarChild();

  return (
   <div className={`sidebar ${isOpen ? 'open' : 'closed'}`}>
      <div className="sidebar-header">
        <button className="btn" onClick={toggleSidebar}>
          <div className={`arrow ${isOpen ? 'left' : 'right'}`}></div>
        </button>
        <h1>{isOpen ? "Ayurmuni" : " "}</h1>
      </div>

      <nav className="nav-menu">
        <ul>
          {SidebarData().map((item, index) => (
            <React.Fragment key={index}>
              <li onClick={() => handleParentClick(item.title)}>
                <Link to={{pathname: item.path}}>
                  {item.icon}
                  {isOpen && item.title}
                </Link>
              </li>

  
              {activeParent === item.title &&
                children
                  .filter((child) => child.parent === item.title)
                  .map((child, childIndex) => (
                    <li key={`child-${childIndex}`} className="child-item">
                      <Link to href={child.path}>
                        {child.icon}
                        {isOpen && child.title}
                      </Link>
                    </li>
                  ))}
            </React.Fragment>
          ))}
        </ul>
      </nav>
</div>
  );
};

export default Sidebar;