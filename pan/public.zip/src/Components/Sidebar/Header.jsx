import React, { useState } from 'react';
import './Header.css';

const Header = () => {
  const [showModal, setShowModal] = useState(false);

  const handleAvatarClick = () => {
    setShowModal((prev) => !prev);
  };

  const handleLogout = () => {
    console.log('User logged out');
    setShowModal(false);
  };

  return (
    <>
      <div className='head1'>
        <div className="header-left">
          <button className="sidebar-toggle">☰</button>
          <div className="breadcrumb">
            <span className="breadcrumb-home">🏠 Home</span>
          </div>
        </div>

        <div className="header-right">
          <div className="user-menu">
            <button className="user-avatar" onClick={handleAvatarClick}>👤</button>
            {showModal && (
              <div className="logout-modal">
                <div className="modal-content">
                  <button className="logout-btn" onClick={handleLogout}>Log Out</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;