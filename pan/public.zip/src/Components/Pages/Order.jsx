
/*import React, { useState, useEffect } from 'react';

const OrderModal = ({ order, onClose }) => {
  if (!order) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Customer Details</h2>
        <p><strong>Order ID:</strong> {order.id}</p>
        <p><strong>Name:</strong> {order.user}</p>
        <p><strong>Date:</strong> {order.created_at}</p>
        <p><strong>Address:</strong> {order.deliveryaddress}</p>
        <p><strong>Amount:</strong> ₹{order.total_amount}</p>
        <p><strong>Status:</strong> {order.order_status}</p>
        <p><strong>Payment Status:</strong> {order.payment_status}</p>
        <button onClick={onClose} className="close-btn">Close</button>
      </div>
    </div>
  );
};

const Order = () => {
  const [orderData, setOrderData] = useState([]);
  const [orderloading, setOrderloading] = useState(true);
  const [ordererror, setOrderError] = useState(null);
  const [searchOrderTerm, setSearchOrderTerm] = useState('');
  const [statusOrderFilter, setStatusOrderFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const getOrderList = async () => {
    try {
      const response = await fetch('https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/order/', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      setOrderData(data);
    } catch (err) {
      console.error(err.message);
      setOrderError('Something went wrong while fetching data.');
    } finally {
      setOrderloading(false);
    }
  };

  useEffect(() => {
    getOrderList();
  }, []);

  const handleDeleteOrder = async (id) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this order?');
    if (!confirmDelete) return;

    try {
      const response = await fetch(`https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/order/${id}/`, {
        method: 'DELETE',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        setOrderData((prevOrders) => prevOrders.filter((order) => order.id !== id));
      } else {
        alert('Failed to delete order');
      }
    } catch (err) {
      console.error(err.message);
      alert('Something went wrong while deleting the order');
    }
  };

  const filteredOrder = orderData.filter((order) => {
    const matchesSearch =
      order.user.toLowerCase().includes(searchOrderTerm.toLowerCase());
    const matchesStatus =
      statusOrderFilter === 'all' || order.order_status === statusOrderFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="order-container">
      <div className="page-header">
        <h1>OrderList</h1>
      </div>

      <div className="order-controls1">
        <div className="search-bar1">
          <input
            type="text"
            placeholder="Search order..."
            value={searchOrderTerm}
            onChange={(e) => setSearchOrderTerm(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="filter-controls1">
          <select
            value={statusOrderFilter}
            onChange={(e) => setStatusOrderFilter(e.target.value)}
            className="status-filter"
          >
            <option value="all">All Status</option>
            <option value="packing">Packing</option>
            <option value="on_the_way">On the Way</option>
            <option value="reached_your_location">Reached Your Location</option>
            <option value="out_for_delivery">Out for Delivery</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      <div className="order-stats">
        <div className="stat-card">
          <h3>Total Orders</h3>
          <div className="stat-value">{orderData.length}</div>
        </div>
        <div className="stat-card">
          <h3>Active Orders</h3>
          <div className="stat-value">
            {orderData.filter((o) => o.order_status === 'on_the_way').length}
          </div>
        </div>
      </div>

      <div className="table-container">
        <table className="order-table">
          <thead>
            <tr>
              <th>Order Id</th>
              <th>Customer Name</th>
              <th>Date</th>
              <th>Address</th>
              <th>Amount</th>
              <th>Payment</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {orderloading ? (
              <tr>
                <td colSpan="8">Loading Order data...</td>
              </tr>
            ) : ordererror ? (
              <tr>
                <td colSpan="8" style={{ color: 'red' }}>{ordererror}</td>
              </tr>
            ) : (
              filteredOrder.map((order) => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.user}</td>
                  <td>{order.created_at}</td>
                  <td>{order.deliveryaddress}</td>
                  <td>₹{order.total_amount}</td>
                  <td>{order.payment_status}</td>
                  <td>{order.order_status}</td>
                  <td>
                    <div className="action-buttons1">
                      <button
                        className="action-btn view1"
                        title="View"
                        onClick={() => {
                          setSelectedOrder(order);
                          setShowModal(true);
                        }}
                      >
                        👁
                      </button>

                      <button
                        className="action-btn delete1"
                        title="Delete"
                        onClick={() => handleDeleteOrder(order.id)}
                      >
                        🗑
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showModal && (
        <OrderModal
          order={selectedOrder}
          onClose={() => {
            setShowModal(false);
            setSelectedOrder(null);
          }}
        />
      )}
    </div>
  );
};

export default Order;*/

import React, { useState, useEffect } from 'react';

const OrderModal = ({ order, onClose }) => {
  if (!order) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Customer Details</h2>
        <p><strong>Order ID:</strong> {order.id}</p>
        <p><strong>Name:</strong> {order.user}</p>
        <p><strong>Date:</strong> {order.created_at}</p>
        <p><strong>Address:</strong> {order.deliveryaddress}</p>
        <p><strong>Amount:</strong> ₹{order.total_amount}</p>
        <p><strong>Status:</strong> {order.order_status}</p>
        <p><strong>Payment Status:</strong> {order.payment_status}</p>
        <button onClick={onClose} className="close-btn">Close</button>
      </div>
    </div>
  );
};

const Order = () => {
  const [orderData, setOrderData] = useState([]);
  const [orderloading, setOrderloading] = useState(true);
  const [ordererror, setOrderError] = useState(null);
  const [searchOrderTerm, setSearchOrderTerm] = useState('');
  const [statusOrderFilter, setStatusOrderFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showModal, setShowModal] = useState(false);
  


  const getOrderList = async () => {
    try {
      const response = await fetch('https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/order/', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      setOrderData(data);
    } catch (err) {
      console.error(err.message);
      setOrderError('Something went wrong while fetching data.');
    } finally {
      setOrderloading(false);
    }
  };

  useEffect(() => {
    getOrderList();
  }, []);
  const handleStatusChange = async (id, newStatus) => {
    try {
      const response = await fetch(`https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/order/${id}/`, {
        method: 'PUT',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ order_status: newStatus }),
      });

      if (response.ok) {
        setOrderData((prevOrders) =>
          prevOrders.map((order) =>
            order.id === id ? { ...order, order_status: newStatus } : order
          )
        );
      } else {
        alert('Failed to update status');
      }
    } catch (err) {
      console.error(err.message);
      alert('Something went wrong while updating the status');
    }
  };



  

  const handleDeleteOrder = async (id) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this order?');
    if (!confirmDelete) return;

    try {
      const response = await fetch(`https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/order/${id}/`, {
        method: 'DELETE',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        setOrderData((prevOrders) => prevOrders.filter((order) => order.id !== id));
      } else {
        alert('Failed to delete order');
      }
    } catch (err) {
      console.error(err.message);
      alert('Something went wrong while deleting the order');
    }
  };

  const filteredOrder = orderData.filter((order) => {
    const matchesSearch = order.user.toLowerCase().includes(searchOrderTerm.toLowerCase());
    const matchesStatus = statusOrderFilter === 'all' || order.order_status === statusOrderFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="order-container">
      <div className="page-header">
        <h1>Order List</h1>
      </div>

      <div className="order-controls1">
        <input
          type="text"
          placeholder="Search order..."
          value={searchOrderTerm}
          onChange={(e) => setSearchOrderTerm(e.target.value)}
          className="search-input"
        />

        <select
          value={statusOrderFilter}
          onChange={(e) => setStatusOrderFilter(e.target.value)}
          className="status-filter"
        >
          <option value="all">All Status</option>
          <option value="packing">Packing</option>
          <option value="on_the_way">On the Way</option>
          <option value="reached_your_location">Reached Your Location</option>
          <option value="out_for_delivery">Out for Delivery</option>
          <option value="delivered">Delivered</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      <div className="order-stats">
        <div className="stat-card">
          <h3>Total Orders</h3>
          <div className="stat-value">{orderData.length}</div>
        </div>
        <div className="stat-card">
          <h3>Active Orders</h3>
          <div className="stat-value">
            {orderData.filter((o) => o.order_status === 'on_the_way').length}
          </div>
        </div>
      </div>

      <div className="table-container">
        <table className="order-table">
          <thead>
            <tr>
              <th>Order Id</th>
              <th>Customer Name</th>
              <th>Date</th>
              <th>Address</th>
              <th>Amount</th>
              <th>Payment</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {orderloading ? (
              <tr>
                <td colSpan="8">Loading Order data...</td>
              </tr>
            ) : ordererror ? (
              <tr>
                <td colSpan="8" style={{ color: 'red' }}>{ordererror}</td>
              </tr>
            ) : (
              filteredOrder.map((order) => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.user}</td>
                  <td>{order.created_at}</td>
                  <td>{order.deliveryaddress}</td>
                  <td>₹{order.total_amount}</td>
                  <td>{order.payment_status}</td>
                  <td>
<select
                      value={order.order_status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value)}
                      className="status-dropdown"
                    >
                      <option value="packing">Packing</option>
                      <option value="on_the_way">On the Way</option>
                      <option value="reached_your_location">Reached Your Location</option>
                      <option value="out_for_delivery">Out for Delivery</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>

</td>


                  <td>
                    <button
                      className="action-btn delete"
                      title="Delete"
                      onClick={() => handleDeleteOrder(order.id)}
                    >
                      🗑
                    </button>
                    <button
                      className="action-btn view"
                      title="View"
                      onClick={() => {
                        setSelectedOrder(order);
                        setShowModal(true);
                      }}
                    >
                      👁
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showModal && (
        <OrderModal
          order={selectedOrder}
          onClose={() => {
            setShowModal(false);
            setSelectedOrder(null);
          }}

        />
      )}
      


    </div>
  );
};

export default Order;