
import React, { useState, useEffect } from 'react';



const initialFormState = {
  store_name: '',
  address: '',
  contact_number: '',
  is_approved: false,
};

const Vendors = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [vendorData, setVendorData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(initialFormState);
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [statusVendor, setStatusVendor] = useState(null);


  useEffect(() => {
    getVendorList();
  }, []);

  const getVendorList = async () => {
    try {
      const res = await fetch('https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/vendor/', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
      const data = await res.json();
      setVendorData(data);
    } catch (err) {
      console.error(err.message);
      setError('Something went wrong while fetching data.');
    } finally {
      setLoading(false);
    }
  };
  const handleStatusClick = (vendor) => {
    setStatusVendor(vendor);
    setStatusModalOpen(true);
  };


  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this vendor?')) return;
    try {
      await fetch(`https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/vendor/${id}/`, {
        method: 'DELETE',
      });
      setVendorData(vendorData.filter((v) => v.id !== id));
    } catch {
      alert('Failed to delete');
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const method = editingId ? 'PUT' : 'POST';
    const url = editingId
      ? `https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/vendor/${editingId}/`
      : 'https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/vendor/';

    try {
      await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(form),
      });
      await getVendorList();
      handleCloseModal();
    } catch (err) {
      alert('Failed to save vendor');
    }
  };
  const updateVendorStatus = async (newStatus) => {
    try {
      const updatedVendor = { ...statusVendor, is_approved: newStatus };

      await fetch(`https://q8f99wg9-8000.inc1.devtunnels.ms/ecom/vendor/${statusVendor.id}/`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedVendor),
      });

      await getVendorList();
      setStatusModalOpen(false);
      setStatusVendor(null);
    } catch (err) {
      alert('Failed to update status');
    }
  };



  const handleCloseModal = () => {
    setModalOpen(false);
    setEditingId(null);
    setForm(initialFormState);
  };


  const filteredVendors = vendorData.filter((vendor) => {
    const matchesSearch =
      vendor.store_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vendor.address.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'approved' && vendor.is_approved) ||
      (statusFilter === 'pending' && !vendor.is_approved);

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="vendors-container">
      <h2>Vendors List</h2>

      <div className="controls-row">
        <div className="search-bar">
          <input
            type="text"
            placeholder="Search vendors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="filter-controls">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
           className='status-filter'
          >
            <option value="all">All Status</option>
            <option value="approved">Approved</option>
            <option value="pending">Pending</option>
            <option value="rejected">Rejected</option>

          </select>

          <button className="add-vendor-btn" onClick={() => setModalOpen(true)}>
            + Add Vendor
          </button>
        </div>
      </div>

      
        <table className="vendors-table">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Location</th>
              <th>Phone Number</th>
              <th>Action</th>
              <th>Status</th>
            </tr>
          </thead>
           {loading ? (
        <p>Loading vendor data...</p>
      ) : error ? (
        <p style={{ color: 'red' }}>{error}</p>
      ) : (
          <tbody>
            {filteredVendors.map((vendor) => (
              <tr key={vendor.id}>
                <td>{vendor.id}</td>
                <td>{vendor.store_name}</td>
                <td>{vendor.address}</td>
                <td>{vendor.contact_number}</td>
                <td>
                  <button
                    className="btn-edit"
                    onClick={() => {
                      setForm(vendor);
                      setEditingId(vendor.id);
                      setModalOpen(true);
                    }}
                  >
                    Edit
                  </button>
                  <button className="btn-delete" onClick={() => handleDelete(vendor.id)}>
                    Delete
                  </button>
                </td>
                <td>
                  <span
                    className={`status-badge ${vendor.is_approved ? 'approved' : 'pending'}`}
          
                    onClick={() => handleStatusClick(vendor)}
                  >

                    {vendor.is_approved === true
                      ? 'approved'
                      : vendor.is_approved === false
                        ? ' pending '
                        : 'rejected'}
                        
                  </span>
                </td>

              </tr>
       ))}
          </tbody>
         )}
        </table>
     

      {modalOpen && (
        <div className="modal">
          <form onSubmit={handleFormSubmit} className="vendor-form">
            <h3>{editingId ? 'Edit Vendor' : 'Add Vendor'}</h3>
            <input className='form-store'
              name="store_name"
              placeholder="Store Name"
              value={form.store_name}
              onChange={handleInputChange}
              required
            />
            <input className='form-address'
              name="address"
              placeholder="Address"
              value={form.address}
              onChange={handleInputChange}
              required
            />
            <input className='form-contact'
              name="contact_number"
              placeholder="Contact Number"
              value={form.contact_number}
              onChange={handleInputChange}
              required
            />
            <label>
              <input className='form-checkbox'
                type="checkbox"
                name="is_approved"
                checked={form.is_approved}
                onChange={handleInputChange}
              />
              Approved
            </label>
            <div className="form-buttons">
              <button type="submit">Save</button>
              <button type="button" onClick={handleCloseModal}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}{statusModalOpen && statusVendor && (
        <div className="modal status-modal">
          <div className="status-modal-content">
            <h3>Update Status</h3>
            <p><strong>Store:</strong> {statusVendor.store_name}</p>
            <p><strong>Current Status:</strong> {statusVendor.is_approved ? 'Approved' : 'Pending'}</p>
            <div className="status-actions">
              <button onClick={() => updateVendorStatus(true)}>Approve</button>
              <button onClick={() => updateVendorStatus(null)}>Reject</button>
              <button onClick={() => setStatusModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}



    </div>
  );
};

export default Vendors;
