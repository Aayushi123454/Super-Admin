
import React, { useEffect, useState } from 'react';
const initalCustomerFormState = {
  first_name: "",
  address: "",
  mobile_number: "",
}

const Customer = () => {
  const [searchcustomerTerm, setSearchcustomerTerm] = useState('');
  const [customerData, setCustomerData] = useState([]);
  const [error, setCustomerError] = useState(null);
  const [Loading, setCustomerLoading] = useState(true);
  const [customerstatusfilter, setCustomerstatusfilter] = useState('All');
  const [CustomerForm, setCustomerForm] = useState(initalCustomerFormState);
  const [editingCustomerId, setEditingCustomerId] = useState(null);
  const [customermodalOpen, setCustomerModalOpen] = useState(false);

  const handleCloseCustomerModal = () => {
    setCustomerModalOpen(false);
    setEditingCustomerId(null);
    setCustomerForm(initalCustomerFormState);
  };
  const handleCustomerFormSubmit = async (e) => {
    e.preventDefault();
    console.log("editcistomerid", editingCustomerId);
    const method = editingCustomerId ? 'PUT' : 'POST';
    const url = editingCustomerId ? `https://q8f99wg9-8000.inc1.devtunnels.ms/api/auth/user_profiles/${editingCustomerId}/` : 'https://q8f99wg9-8000.inc1.devtunnels.ms/api/auth/user_profiles/';
   console.log('url',url)
    try {
      await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(CustomerForm),
      });

      console.log("respnsedata", CustomerForm);
      await getCustomerList();
      
      handleCloseCustomerModal();
    }
    catch (err) {
      alert('Failed to save vendor');
    }
  }

  const handleCustomerDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this vendor?')) return;
    try {
      await fetch(`https://q8f99wg9-8000.inc1.devtunnels.ms/api/auth/user_profiles/${id}/`, {
        method: 'DELETE'
      })
        ;
      setCustomerData(customerData.filter((c) => c.id !== id));
    }
    catch {

      alert('Failed to delete');
    }
  }

  const handleCustomerInputChange = (e) => {
    const { name, value } = e.target;

    setCustomerForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const getCustomerList = async () => {
    try {
      const response = await fetch('https://q8f99wg9-8000.inc1.devtunnels.ms/api/auth/user_profiles/', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      console.log('')
      setCustomerData(data);
    } catch (err) {
      console.error(err.message);
      setCustomerError('Something went wrong while fetching data.');
    } finally {
      setCustomerLoading(false);
    }
  };


  useEffect(() => {
    getCustomerList();
  }, []);

  const filteredCustomers = customerData.filter((customer) =>
    customer.first_name.toLowerCase().includes(searchcustomerTerm.toLowerCase())
  );
  return (
    <div className="customer-container">
      <h2>Customer List</h2>
      <div className='controls-row'>
        <div className='search-bar'>
          <input className="search-input"
            type="text"
            placeholder='search customer...'
            value={searchcustomerTerm}
            onChange={(e) => setSearchcustomerTerm(e.target.value)}
          />
        </div>
        <div className='filter-controls'>
          <select className='status-filter'
            value={customerstatusfilter}
            onChange={(e) => setCustomerstatusfilter(e.target.value)
            }>
            <option value="all">All Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>



          </select>
          <button className="add-customer-btn" onClick={() => setCustomerModalOpen(true)} >
            + Add customer
          </button>
        </div>
      </div>

      <table className="customer-table">
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Location</th>
            <th>Phone Number</th>
            <th>Action</th>
            <th>Status</th>
          </tr>
        </thead>
        {Loading ? (
          <p>Loading customer data...</p>
        ) : error ? (
          <p style={{ color: 'red' }}>{error}</p>
        ) : (

          <tbody>

            {filteredCustomers.map((customer) => (
              <tr key={customer.id}>
                <td>{customer.id}</td>
                <td>{customer.first_name}</td>
                <td>{customer.address}</td>
                <td>{customer.mobile_number}</td>
                <td>
                  <button className='btn-edit'
                    onClick={() => {
                      setCustomerForm(customer);
                      setEditingCustomerId(customer.id);
                      setCustomerModalOpen(true);
                    }}


                  > Edit</button>
                  <button className='btn-delete' onClick={() => handleCustomerDelete(customer.id)}>Delete</button>
                </td>
                <td>{ }</td>
              </tr>
            ))}
          </tbody>
        )}
      </table>

      {customermodalOpen && (
        <div className="modal">
          <form className="customer-form" onSubmit={handleCustomerFormSubmit}>
            <h3>{editingCustomerId ? 'Edit Customer' : 'Add Customer'}</h3>

            <input
              type="text"
              name="first_name"
              placeholder='Enter your first name'
              value={CustomerForm.first_name}
              onChange={handleCustomerInputChange}
              required />
            <input
              type="string"
              name="address"
              placeholder=" Enter your address"
              value={CustomerForm.address}
              onChange={handleCustomerInputChange}
              required />

            <input
              type="number"
              name="mobile_number"
              placeholder="Enter your Phone number"
              onChange={handleCustomerInputChange}
              value={CustomerForm.mobile_number}
              required />
            <div className="form-buttons">
              <button type="submit"> Save</button>
              <button type="button" onClick={handleCloseCustomerModal}>Cancel</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default Customer;