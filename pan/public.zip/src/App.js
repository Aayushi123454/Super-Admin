

import './App.css';
import { BrowserRouter as Router, Routes, Route, } from 'react-router-dom';
import Sidebar from './Components/Sidebar/Sidebar';
import Product from './Components/Pages/Product';
import Order from './Components/Pages/Order';
import Dashboard from './Components/Pages/Dashboard';
import Customer from './Components/Pages/Customer';
import Vendors from './Components/Pages/Vendors';
import History from './Components/Pages/History';
import Header from './Components/Sidebar/Header';


function App() {
  
  
  return (
    <Router>
     <Header/>
      <Sidebar />
      <div className="main-content">
        <Routes>
          
         
          <Route path="/" element={<Product />} />
         <Route path="/Order" element={<Order />} />
          <Route path="/Dashboard" element={<Dashboard />} />
          <Route path="/Customer" element={<Customer />} />
          <Route path="/Vendors" element={<Vendors />} />
          <Route path="/History" element={<History />} />
        </Routes>
      </div>
    </Router>
  

  );
}

export default App;
